import { Link } from "react-router-dom";
import { FaUserCircle, FaUser } from "react-icons/fa";

export default function BottomBar({ collapsed, email }) {
    return (
        <div
            className={`border-t border-[#212121] px-3 py-3 text-sm text-white
                  h-[70px] shrink-0 flex items-center relative
                  ${collapsed ? "justify-center" : "justify-start"}`}
        >
            {/* текстовое представление */}
            <div
                className={`overflow-hidden whitespace-nowrap transition-all
                    ${
                        collapsed
                            ? "opacity-0 max-w-0 pointer-events-none absolute"
                            : "opacity-100 max-w-full"
                    }`}
                aria-hidden={collapsed}
            >
                {email ? (
                    <>
                        Вы вошли как
                        <br />
                        <span className="font-medium block truncate">
                            {email}
                        </span>
                    </>
                ) : (
                    <Link to="/login" className="text-blue-400 hover:underline">
                        Воцти
                    </Link>
                )}
            </div>

            {/* иконка при свернутом меню */}
            <div
                className={`transition-all
                    ${
                        collapsed
                            ? "opacity-100"
                            : "opacity-0 pointer-events-none"
                    }`}
                aria-hidden={!collapsed}
            >
                {email ? (
                    <FaUserCircle size={20} className="text-gray-300" />
                ) : (
                    <Link to="/login">
                        <FaUser size={18} className="text-blue-400" />
                    </Link>
                )}
            </div>
        </div>
    );
}
